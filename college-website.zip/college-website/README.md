how to create college website
