import React from 'react'
import Gallery from '../Components/Gallery'

const Gallerypage = () => {
  return (
    <>
    <Gallery />
    </>
  )
}

export default Gallerypage