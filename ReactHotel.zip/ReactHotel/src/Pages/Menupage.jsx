import React from 'react'
import Menu from '../Components/Menu'

const Menupage = () => {
  return (
    <>
    <Menu />
    </>
  )
}

export default Menupage