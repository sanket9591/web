import React from 'react'
import About from '../Components/About'

const Aboutpage = () => {
  return (
    <>
    <About />
    </>
  )
}

export default Aboutpage