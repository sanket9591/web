import React from 'react'
import Contact from '../Components/Contact'

const Contactpage = () => {
  return (
    <>
    <Contact />
    </>
  )
}

export default Contactpage