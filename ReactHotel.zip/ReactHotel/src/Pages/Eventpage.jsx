import React from 'react'
import Events from '../Components/Events'

const Eventpage = () => {
  return (
    <>
    <Events />
    </>
  )
}

export default Eventpage